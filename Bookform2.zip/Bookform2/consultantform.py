import sys


from PyQt5.uic import loadUi
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QApplication, QWidget
from PyQt5.uic import loadUiType
from PyQt5.QtGui import *
import sqlite3

class Consultant(QDialog):
    def __init__(self):
        super(Consultant, self).__init__()
        loadUi('consultant.ui',self)
        self.resize(591, 791)
        # таблица заказы
        self.tableWidget_orders.setColumnWidth(0, 60)
        self.tableWidget_orders.setColumnWidth(1, 70)
        self.tableWidget_orders.setColumnWidth(2, 100)
        self.tableWidget_orders.setColumnWidth(4, 50)
        self.tableWidget_orders.setColumnWidth(5, 50)
        self.tableWidget_orders.setColumnWidth(6, 75)

        self.loaddata_orders()
        self.loaddata_goods()


    def loaddata_orders(self):
        connection = sqlite3.connect('bookfrom.db')
        cur = connection.cursor()
        sqlquery = '''SELECT ord.id_orders, ord.data_orders, b.title, au.name_author, g.name_genre,
         b.price, ord.amount, emp.name_emp, cl.name_client 
         FROM orders ord INNER JOIN book b on b.id_book=ord.id_book INNER JOIN
         author au on au.author_id=b.id_author INNER JOIN genre g
         on g.genre_id=b.genre_id LEFT JOIN client cl 
         on ord.id_client=cl.id_client INNER JOIN employees emp 
         on emp.id_employe=ord.id_employe'''
        self.tableWidget_orders.setRowCount(10)
        tablerow = 0
        for row in cur.execute(sqlquery):
            self.tableWidget_orders.setItem(tablerow, 0, QtWidgets.QTableWidgetItem(str(row[0])))
            self.tableWidget_orders.setItem(tablerow, 1, QtWidgets.QTableWidgetItem(str(row[1])))
            self.tableWidget_orders.setItem(tablerow, 2, QtWidgets.QTableWidgetItem(str(row[2])))
            self.tableWidget_orders.setItem(tablerow, 3, QtWidgets.QTableWidgetItem(str(row[3])))
            self.tableWidget_orders.setItem(tablerow, 4, QtWidgets.QTableWidgetItem(str(row[4])))
            self.tableWidget_orders.setItem(tablerow, 5, QtWidgets.QTableWidgetItem(str(row[5])))
            self.tableWidget_orders.setItem(tablerow, 6, QtWidgets.QTableWidgetItem(str(row[6])))
            self.tableWidget_orders.setItem(tablerow, 7, QtWidgets.QTableWidgetItem(str(row[7])))
            self.tableWidget_orders.setItem(tablerow, 8, QtWidgets.QTableWidgetItem(str(row[8])))

            tablerow += 1

        # загрузка бд товары
    def loaddata_goods(self):
        connection = sqlite3.connect('bookfrom.db')
        cur = connection.cursor()
        sqlquery = '''SELECT  b.title, au.name_author, g.name_genre, b.amount, b.price FROM book b
        INNER JOIN author au on au.author_id=b.id_author
        INNER JOIN genre g on g.genre_id=b.genre_id'''
        self.tableWidget_goods.setRowCount(8)
        tablerow = 0
        for row in cur.execute(sqlquery):
            self.tableWidget_goods.setItem(tablerow, 0, QtWidgets.QTableWidgetItem(str(row[0])))
            self.tableWidget_goods.setItem(tablerow, 1, QtWidgets.QTableWidgetItem(str(row[1])))
            self.tableWidget_goods.setItem(tablerow, 2, QtWidgets.QTableWidgetItem(str(row[2])))
            self.tableWidget_goods.setItem(tablerow, 3, QtWidgets.QTableWidgetItem(str(row[3])))
            self.tableWidget_goods.setItem(tablerow, 4, QtWidgets.QTableWidgetItem(str(row[4])))

            tablerow += 1




"""app=QApplication(sys.argv)
consultant =Consultant()
widget = QtWidgets.QStackedWidget()
widget.addWidget(consultant)
widget.setFixedHeight(591)
widget.setFixedWidth(791)
widget.show()
try:
    sys.exit(app.exec_())
except:
    print('"Exiting"')"""
