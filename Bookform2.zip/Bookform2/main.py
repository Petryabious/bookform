import sys

from PyQt5.uic import loadUi
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QApplication, QWidget
from PyQt5.uic import loadUiType
from PyQt5.QtGui import *
import sqlite3
from adminfrom import *
from sallerform import *
from consultantform import*



class WelcomeScreen(QDialog):
    def __init__(self):
        super(WelcomeScreen, self).__init__()
        loadUi('welcomescreen.ui', self)
        self.login1.clicked.connect(self.gotologin)
        self.exitbutton.clicked.connect(sys.exit)
        self.setWindowTitle('Книжный магазин')



    def gotologin(self):
        # login = LoginScreen()
        # widget.addWidget(login)
        widget.setCurrentIndex(widget.currentIndex() + 1)


class LoginScreen(QDialog):
    def __init__(self):
        super(LoginScreen, self).__init__()
        loadUi('login.ui', self)

        self.passwordfield.setEchoMode(QtWidgets.QLineEdit.Password)
        self.login.clicked.connect(self.loginfunction)
        self.backbutton.clicked.connect(self.backtothemain)
        # self.login.clicked.connect(self.gotoadmin)

    def backtothemain(self):
        widget.setCurrentIndex(0)

    #def gotoadmin(self):
        #admin = Adminform()
        #widget.addWidget(admin)

        #widget.setCurrentIndex(2)

    def loginfunction(self):

        user = self.emailfield.text()
        password = self.passwordfield.text()
        if len(user) == 0 or len(password) == 0:
            self.error.setText("Пожалуйста заполните все поля")
        elif user != 'admin' and user!='saller' and user!='consultant':
            self.error.setText('Неправильный логин или пароль')

        else:
            conn = sqlite3.connect('bookfrom.db')
            cur = conn.cursor()
            query = 'SELECT  password FROM login_info WHERE username =\'' + user + "\'"
            cur.execute(query)

            result_pass = cur.fetchone()[0]

            if result_pass == password and user == 'admin' :
                widget.setCurrentIndex(2)
                widget.setFixedHeight(591)
                widget.setFixedWidth(751)
                #self.login.clicked.connect(self.gotoadmin)
                print("Successfully logged in")

            elif result_pass==password and user=='saller':
                widget.setCurrentIndex(3)
                widget.setFixedHeight(591)
                widget.setFixedWidth(751)
            elif result_pass==password and user=='consultant':
                widget.setCurrentIndex(4)
                widget.setFixedHeight(591)
                widget.setFixedWidth(751)
            else:
                self.error.setText('Неправильный логин или пароль')



# main
app = QApplication(sys.argv)
welcome = WelcomeScreen()
widget = QtWidgets.QStackedWidget()
widget.addWidget(welcome)
widget.setFixedHeight(400)
widget.setFixedWidth(600)
widget.show()

login = LoginScreen()
widget.addWidget(login)
#admin form
admin = Adminform()
widget.addWidget(admin)
#saller form
sallerform=Sallerform()
widget.addWidget(sallerform)
#consultant form
consultant=Consultant()
widget.addWidget(consultant)


try:
    sys.exit(app.exec_())
except:
    print("Exiting")

input()
